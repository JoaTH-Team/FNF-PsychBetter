Put your custom states here

the extension can be `.lua` for lua states or `.hx` for haxe states